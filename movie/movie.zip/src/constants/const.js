export const API_URL = 'https://film.apppi.pl/api/';
export const API_CATEGORIES_URL = API_URL + 'category';
export const API_CATEGORY_URL = API_URL + 'category/';
export const API_MOVIE_URL = API_URL + 'movie/';
export const API_URL_USER_REGISTER = API_URL + 'auth/register';

export const API_URL_USER_LOGIN = API_URL +'auth/login';
export const API_URL_GET_AUTH_USER = API_URL +'auth/get-authenticated-user';