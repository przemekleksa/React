import React from 'react';
import SliderHomepage from '../../components/slider/slider';

const Homepage = () => {
    return ( 
        <div >
            <SliderHomepage />
            <div className="container">
            </div>
        </div>
     );
}
 
export default Homepage;