import React, { Component } from 'react';

class AddMovie extends Component {
    state = {  }
    render() { 
        return ( 
            <div className="container"> 
                add movie
                {/* <form>
                    <label htmlFor="title">Title</label>
                    <input type="text" id="title" onChange={}></input>
                    <label htmlFor="">Title</label>
                    <input type="text" id="title" onChange={}></input>
                    <label htmlFor="title">Title</label>
                    <input type="text" id="title" onChange={}></input>
                </form> */}
            </div>
         );
    }
}
 
export default AddMovie;