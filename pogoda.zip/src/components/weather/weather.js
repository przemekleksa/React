import React, { Component } from 'react';
import Loader from '../loader/loader';


class Weather extends Component {
    state = {}
    render() {
        return (
            <div>
                pogoda
                <Loader isLoading={true} />
            </div>
        );
    }
}

export default Weather;